# Ploan NETC Mock API

This is a mock server for PLOAN (NETC)

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.<br>
[http://localhost:3300](http://localhost:3300).