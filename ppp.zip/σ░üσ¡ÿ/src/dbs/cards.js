const Module = require('module')
const express = require('express')
const fs = require('fs')
const faker = require('faker')
const router = express.Router()
const sortBy = require('lodash/sortby')
const RandomArray = require('../dbs-lib/FnRandomArray.js')
faker.locale = 'zh_TW'

Module._extensions['.png'] = function (module, fn) {
  var base64 = fs.readFileSync(fn).toString('base64')
  module._compile('module.exports="data:image/png;base64,' + base64 + '"', fn)
}

const cards = [require('../assets/card1.png'),
  require('../assets/card2.png'),
  require('../assets/big_month.png'),
  require('../assets/card3.png')]
const cardTypes = ['fly', 'cash', 'bonus']
const cardIds = ['100', '110', '120', '130', '140', '150', '160', '170', '180', '190', '200', '240', '300', '400', '500']

router.post('/cards', (req, res, next) => {
  const data = cardIds.map((cardId) => {
    return {
      locale: 'zh',
      cardProdID: cardId,
      cardType: RandomArray.get(cardTypes),
      cardName: faker.name.lastName() + '卡',
      cardFace: RandomArray.get(cards),
      moreInfo: 'https://www.dbs.com.tw/cardintro/100',
      benefit1: faker.lorem.words(faker.random.number({'min': 3, 'max': 6})),
      benefit2: faker.lorem.words(faker.random.number({'min': 3, 'max': 6})),
      benefit3: faker.lorem.words(faker.random.number({'min': 3, 'max': 6}))
    }
  })
  res.json(sortBy(data, ['cardProdID']))
})

module.exports = router
