const registerRemind = {
    content: `
這是一個"注冊"的注意事項，
會有多行
請注意排版
不要跑版了。
`   ,
    tcVersion: '1.0',
    tcVersionSEQ: '0987987789'
};

module.exports.registerRemind = registerRemind;